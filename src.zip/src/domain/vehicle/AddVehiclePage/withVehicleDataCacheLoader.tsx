import { RouteComponentProps } from 'react-router-dom';
import { graphql, QueryProps } from "react-apollo";
import * as LoadVehicleDataCacheQueryGql from './_queries/LoadVehicleDataCacheQuery.graphql';
import {ReactFunctionOrComponentClass, LoadAddVehicleDataCacheType} from '../../types';
import withLoadingHandler from '../../../components/withLoadingHandler';


type withVehicleDataCachePageDataLoaderProps = RouteComponentProps<{
  collegeId: string;
  branchId: string;
  }>;

type TargetComponentProps = {
    data: QueryProps & LoadAddVehicleDataCacheType ;
};

const withVehicleDataCacheLoader = (TargetComponent: ReactFunctionOrComponentClass<TargetComponentProps>) => {
    return graphql<LoadAddVehicleDataCacheType, withVehicleDataCachePageDataLoaderProps, TargetComponentProps>(LoadVehicleDataCacheQueryGql, {
      options: ({ match }) => ({
        variables: {
          collegeId: 951,
          branchId: 1151
        }
      })
    })(withLoadingHandler(TargetComponent));
};

export default withVehicleDataCacheLoader 
