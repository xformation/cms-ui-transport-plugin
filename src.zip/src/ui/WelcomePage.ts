export class WelcomePage {
    static templateUrl = '/partials/welcome.html';
}