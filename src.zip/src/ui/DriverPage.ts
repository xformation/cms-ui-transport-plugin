import init from '../domain/driver/DriverListPage/DriverApp';

export class DriverPage {
    static templateUrl = '/partials/driver.html';
    constructor() {
        init();
    }
}