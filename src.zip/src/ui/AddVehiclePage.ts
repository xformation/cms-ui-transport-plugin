import init from '../domain/vehicle/AddVehiclePage/AddVehicleApp';

export class AddVehiclePage {
  static templateUrl = '/partials/addvehicle.html';
  constructor() {
    init();
  }
}