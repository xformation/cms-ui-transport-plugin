import init from '../domain/vehicle/VehiclePage/VehiclesApp';

export class VehiclesPage {
  static templateUrl = '/partials/vehiclepage.html';
  constructor() {
    init();
  }
}
