import {WelcomePage} from './ui/WelcomePage';
import {VehiclePage} from './ui/VehiclePage';
import {DriverPage} from './ui/DriverPage';
import {VehiclesPage} from './ui/VehiclesPage';
import {AddVehiclePage} from './ui/AddVehiclePage';
export {
    WelcomePage,
    VehiclePage,
    DriverPage,
    VehiclesPage,
    AddVehiclePage
    };
